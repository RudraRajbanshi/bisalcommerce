<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


<a href = "<?php echo e(url('category/create')); ?>" class = 'btn btn-primary
'>Create Category</a>

	<table class = 'table table-striped'>
		<tr>
			<td>Category Name</td>
			<td>Category Description</td>
			<td>Action</td>
		</tr>

		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($c['category_name']); ?></td>
			<td><?php echo e($c['category_description']); ?></td>
			<td><a class = 'btn btn-primary' style = 'float:left' href = "<?php echo e(url('category/edit/'.$c['id'])); ?>">Edit</a> <form action = "<?php echo e(url('category/delete')); ?>" method = 'POST'>
				<input type = 'hidden' name = 'id' value = "<?php echo e($c['id']); ?>" />
				<input type = 'hidden' name = '_token' value = '<?php echo e(csrf_token()); ?>' />
				<input type = 'hidden' name = '_method' value = 'DELETE' />
				<input type = 'submit' value = 'Delete' class = 'btn btn-danger'/>
			</form></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<?php echo e($categories->links()); ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>