<?php $__env->startSection('content'); ?>
	
<div class="blog-post-area">
						<h2 class="title text-center">Your Cart</h2>
						<div class="single-blog-post">
						
						<form action = "<?php echo e(url('cart/edit')); ?>" method = 'POST'>	
						<table class = 'table table-striped'>
							<tr>
								<td>Product Name</td>
								<td>Image</td>
								<td>Qty</td>
								<td>Price</td>
								<td>Total</td>
								<td></td>
							</tr>
							<?php $total = 0; ?>
							<?php $__currentLoopData = $cart_main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($val['name']); ?></td>
								<td><img style = "height:120px; width:auto;' >" src = "<?php echo e(URL::to('/').'/uploads/'.$val['image']); ?>"></td>
								<td><input max = "<?php echo e($val['qty']); ?>" type = 'number' value = "<?php echo e($val['cartqty']); ?>" name = "qty[<?php echo e($val['id']); ?>]"></td>
								<td><?php echo e($val['price']); ?></td>
								<td><?php echo e($val['price']*$val['cartqty']); ?> </td>
								<td><a class = 'btn btn-danger' href = "<?php echo e(url('cart/delete/'.$val['id'])); ?>">X</a></td>
							</tr>
							<?php $total = $total + ($val['price']*$val['cartqty']); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						Total Price : <?php echo e($total); ?><br>
						<input type = 'hidden' name = '_token' value = '<?php echo e(csrf_token()); ?>' />
						<input type = 'submit' class = 'btn btn-success' value = 'Update Cart'/>
						</form>
						</div>
						<br>	
						<h2 class="title text-center">Checkout</h2>
					<form action = "<?php echo e(url('order/add')); ?>" method = 'POST'>
						Full Name : <input type = 'text' name = 'fullname' class = 'form-control' value = "<?php echo e(Auth::user()->name); ?>" required/><br>
						Email : <input type = 'text' name = 'email' class = 'form-control' value = "<?php echo e(Auth::user()->email); ?>" required/><br>
						Phone No : <input type = 'text' name = 'phone' class = 'form-control' required/><br>
						Address : <input type = 'text' name = 'address' class = 'form-control' required/><br>
						Delivery Location : <input type = 'text' name = 'location' class = 'form-control' required/><br>
						<?php $__currentLoopData = $cart_main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<input max = "<?php echo e($val['qty']); ?>" type = 'hidden' value = "<?php echo e($val['cartqty']); ?>" name = "qty[<?php echo e($val['id']); ?>]">
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<input type = 'hidden' name = '_token' value = '<?php echo e(csrf_token()); ?>' /> 
						<input type = 'submit' class = 'btn btn-primary' />
					</form>

					</div>

					

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>