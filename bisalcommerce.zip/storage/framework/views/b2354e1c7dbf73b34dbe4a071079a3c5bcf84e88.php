<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>



<h3>Add a New Product</h3>

<form action = "<?php echo e(url('product/edit')); ?>" method = 'POST' enctype="multipart/form-data">

	Product name : <input type = 'text' class = 'form-control' name = 'pname' value = "<?php echo e(old('pname',$product['name'])); ?>" /><br>
	Qty : <input type = 'text' name = 'qty' class = 'form-control' value = "<?php echo e(old('qty',$product['qty'])); ?>"/><br>

	Price : <input type = 'text' name = 'price' class = 'form-control' value = "<?php echo e(old('price',$product['price'])); ?>"/><br>
	Discount : <input type = 'text' name = 'discount' class = 'form-control' value = "<?php echo e(old('discount',$product['discount'])); ?>"/><br>

	Is Featured : Yes<input type = 'radio' name = 'featured' value = 'yes' <?php if(old('featured',$product['is_featured']) == 'yes'): ?> checked <?php endif; ?>/>
	No<input type = 'radio' name = 'featured' value = 'no' <?php if(old('featured',$product['is_featured']) == 'no'): ?> checked <?php endif; ?>/>
	<br>
	<br>
	<img src = "<?php echo e(URL::to('/').'/uploads/'.$product['image']); ?>" height="120px" />
	<br>

	Image(if changing) : <input type = 'file' class = 'form-control' name = 'image' /><br>

	Choose Category : <select class = 'form-control' name = 'categoryid'>
		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		<option value="<?php echo e($value['id']); ?>" <?php if(old('categoryid',$product['category_id']) == $value['id']): ?> selected <?php endif; ?>><?php echo e($value['category_name']); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select><br>

	Detail : <textarea class = 'form-control' name = 'detail'><?php echo e(old('detail',$product['detail'])); ?></textarea><br>
	<input type = 'hidden' name = '_token' value = '<?php echo e(csrf_token()); ?>' />
	<input type = 'hidden' name = 'id' value = "<?php echo e($product['id']); ?>" />
	<input type = 'hidden' name = '_method' value = 'PUT' />
	<input type = 'submit' class = 'btn btn-primary'/>

</form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>












<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>