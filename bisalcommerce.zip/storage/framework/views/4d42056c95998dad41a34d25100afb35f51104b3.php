<?php $__env->startSection('content'); ?>
	
<div class="blog-post-area">
						<h2 class="title text-center">Your Wishlist</h2>
						<div class="single-blog-post">
							
						<table class = 'table table-striped'>
							<tr>
								<td>Product Name</td>
								<td>Image</td>
								
								<td>Price</td>
								<td></td>
							</tr>
							<?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($val->product['name']); ?></td>
								<td><img style = "height:120px; width:auto;' >" src = "<?php echo e(URL::to('/').'/uploads/'.$val->product['image']); ?>"></td>
								
								<td><?php echo e($val->product['price']); ?></td>
								
								<td><a class = 'btn btn-danger' href = "<?php echo e(url('wishlist/delete/'.$val->product['id'])); ?>">X</a></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						
						
						</div>
						
					</div>

					

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>