<?php $__env->startSection('content'); ?>


	<?php if(\Session::has('msg')): ?>
	<div class = 'alert alert-success'>
		<p><?php echo e(\Session::get('msg')); ?></p>
	</div></br>
	<?php endif; ?> 

	<?php if($errors->any()): ?>
	<div class = 'alert alert-danger'>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($e); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>

<h3>Change Password</h3>
<form action = "<?php echo e(url('user/changepassword')); ?>" method = 'POST'>
	Old Password : <input type = 'password' name = 'opass' class = 'form-control' ><br>
	New Password : <input type = 'password' name = 'npass' class = 'form-control' ><br>
	Confirm Password : <input type = 'password' name = 'ncpass' class = 'form-control' ><br>
	<input type = 'hidden' name = '_token' value="<?php echo e(csrf_token()); ?>">
	<input type = 'submit' class = 'btn btn-primary'/>
</form>
					
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>