<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<ul>
	<li>Home</li>
	<li>About</li>
	<li>Contact</li>
</ul>

	<?php if(\Session::has('msg')): ?>
	<div class = 'alert alert-success'>
		<p><?php echo e(\Session::get('msg')); ?></p>
	</div></br>
	<?php endif; ?> 

	<?php if($errors->any()): ?>
	<div class = 'alert alert-danger'>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($e); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>

	<?php echo $__env->yieldContent('content'); ?>

<footer>Just a test footer.</footer>
</body>
</html>