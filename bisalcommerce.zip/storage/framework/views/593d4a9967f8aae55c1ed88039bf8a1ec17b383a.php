<?php $__env->startSection('content'); ?>

<div class="product-details"><!--product-details-->
						<div class="col-sm-5">
							<div class="view-product">
								<img src="<?php echo e(asset('uploads/'.$product['image'])); ?>" alt="" />
								
							</div>
						

						</div>
						<div class="col-sm-7">
							<div class="product-information"><!--/product-information-->
								<img src="images/product-details/new.jpg" class="newarrival" alt="" />
								<h2><?php echo e($product['name']); ?></h2>
								
								<img src="images/product-details/rating.png" alt="" />
								<span>
									<?php if($product['discount'] != 0): ?>
									<span style = 'text-decoration: line-through'>Rs. <?php echo e($product['price']); ?></span>
									<?php endif; ?>
									<span>Rs. <?php echo e($product['price'] - ($product['discount']*$product['price']/100)); ?></span>
									
									<?php if(Auth::check()): ?>
											<a href="<?php echo e(url('cart/add/'.$product['id'])); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
											<?php endif; ?>
								</span>
								<p><b>Qty:</b> <?php echo e($product['qty']); ?></p>
								<p><b>Discount:</b><?php echo e($product['discount']); ?></p>
								<p class = 'showmore' style = 'overflow:hidden; height: 100px;'><b>Detail:</b> <?php echo e($product['detail']); ?></p>
								<a style = 'cursor:pointer' class = 'readmore'>Read More</a>
								<a href=""><img src="images/product-details/share.png" class="share img-responsive"  alt="" /></a>
							</div><!--/product-information-->
						</div>
					</div><!--/product-details-->
					

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>