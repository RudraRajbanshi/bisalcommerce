<?php $__env->startSection('content'); ?>
	
<div class="blog-post-area">
						<h2 class="title text-center"><?php echo e($page['page_name']); ?></h2>
						<div class="single-blog-post">
							
							<p><?php echo e($page['content']); ?></p>
							
						</div>
						
					</div>

					

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>