<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Orders</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>



    <h2>Order Details</h2>
	<p>Name: <?php echo e($order['name']); ?></p>
	<p>Phone: <?php echo e($order['phone']); ?></p>
	<p>User Name: <?php echo e($order->user['name']); ?></p>
	<p>Status: <?php echo e($order['status']); ?></p>
	<p>Delivery Location: <?php echo e($order['location']); ?></p>
	<p>Created Date: <?php echo e($order['created_at']); ?></p>

	<h2>Product Details</h2>
	<?php $__currentLoopData = $finalProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<p><?php echo e($v['name']); ?> : <?php echo e($v['orderqty']); ?></p>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<form action = "<?php echo e(url('order/changestatus')); ?>" method="POST">
	Status : <select name = 'status' class = 'form-control'>
				<option value = 'pending' <?php if($order['status']=='pending'): ?> selected <?php endif; ?>>Pending</option>
				<option value = 'delivered' <?php if($order['status']=='delivered'): ?> selected <?php endif; ?>>Delivered</option>
				<option value = 'cancelled' <?php if($order['status']=='cancelled'): ?> selected <?php endif; ?>>Cancelled</option>
			</select>
			<input type = 'hidden' name = 'orderId' value = "<?php echo e($order['id']); ?>" />
			<input type = 'hidden' name = '_token' value = '<?php echo e(csrf_token()); ?>' />
			<br>
			<input type = 'submit' class = 'btn btn-primary' />

	</form>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>