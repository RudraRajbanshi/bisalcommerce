<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


<h3>Add a New Product</h3>

<form action = "<?php echo e(url('product/create')); ?>" method = 'POST' enctype="multipart/form-data">
	Product name : <input type = 'text' class = 'form-control' name = 'pname' value = "<?php echo e(old('pname')); ?>" /><br>
	Qty : <input type = 'text' class = 'form-control' name = 'qty' value = "<?php echo e(old('qty')); ?>"/><br>
	Price : <input type = 'text' class = 'form-control' name = 'price' value = "<?php echo e(old('price')); ?>"/><br>
	Discount : <input type = 'text' class = 'form-control' name = 'discount' value = "<?php echo e(old('discount')); ?>"/><br>



	Is Featured : Yes<input type = 'radio' name = 'featured' value = 'yes' <?php if(old('featured') == 'yes'): ?> checked <?php endif; ?>/>
	No<input type = 'radio' name = 'featured' value = 'no' <?php if(old('featured') == 'no'): ?> checked <?php endif; ?>/>
	<br><br>
	Image : <input type = 'file' class = 'form-control' name = 'image' /><br>

	Choose Category : <select class = 'form-control' name = 'categoryid'>
		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		<option value="<?php echo e($value['id']); ?>" <?php if(old('categoryid') == $value['id']): ?> selected <?php endif; ?>><?php echo e($value['category_name']); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select><br>
	Detail : <textarea class = 'form-control' name = 'detail'><?php echo e(old('detail')); ?></textarea><br>
	<input type = 'hidden' name = '_token' value = '<?php echo e(csrf_token()); ?>' />
	<input type = 'submit' class = 'btn btn-primary' />

</form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>