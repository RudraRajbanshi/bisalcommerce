<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

	<form action = "<?php echo e(url('/page/edit')); ?>" method = 'POST'>
		Page Name: <input type = 'text' class = 'form-control' name = 'page_name'  value = "<?php echo e($page['page_name']); ?>" />
		<br>
		Content Description : <textarea class = 'form-control' name = 'content'><?php echo e($page['content']); ?></textarea>	
		<br>
		<input type = 'hidden' name = '_token' value = '<?php echo e(csrf_token()); ?>' />
		<input type = 'hidden' name = '_method' value = 'PUT' />

		<input type = 'hidden' name = 'id' value = "<?php echo e($page['id']); ?>" />
		<input type = 'submit' value = 'Edit' class = 'btn btn-primary' />	
	</form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>









<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>