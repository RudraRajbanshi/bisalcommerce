<!DOCTYPE html>
<html>
<head>
	<title>Marksheet</title>
</head>
<body>
<h2>Student Name: {{ $student_name }}</h2>
<h3>SNO : {{ $sno}}</h3>
<h2>Marks : </h2>
<h3>Java : {{ $java }} </h3>

<h3>Status : {{ $status }} </h3>
</body>
</html>